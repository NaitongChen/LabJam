package panels;

public class Constant {
	public static final String LOGIN = "login";
	public static final String RESEARCHERMAIN = "researcherMain";
	public static final int RESEARCHERDIR = 0;
	public static final String COLLABORATORMAIN = "collaboratorMain";
	public static final int COLLABORATORDIR = 1;
	public static final String PIMAIN = "piMain";
	public static final int PIDIR = 2;
	public static final String LABMANAGERMAIN = "labManagerMain";
	public static final int LABMANAGERDIR = 3;
	public static final String DBAMAIN = "dbaMain";
	public static final int DBADIR = 4;
	public static final String PROJECT = "project";
	public static final String LAB = "lab";
}
