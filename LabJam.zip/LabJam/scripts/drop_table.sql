DROP VIEW ProjectName_MaterialPrice;

DROP VIEW ProjectName_Funding;

DROP TABLE Makes_Booking;

DROP TABLE Participates;

DROP TABLE Takes_Booking;

DROP TABLE Subject;

DROP TABLE Name_Education_ProjectName;

DROP TABLE Assigned_Collaborators_Id;

DROP TABLE Role_WeeklyHoursAllocated;

DROP TABLE Supervises_WorksOn;

DROP TABLE Fund_ApprovedGrant;

DROP TABLE Date_Name_Lmid;

DROP TABLE Applies_OpenGrant_Date;

DROP TABLE MaterialType_MaterialPrice;

DROP TABLE Project_MaterialType;

DROP TABLE Researcher;

DROP TABLE PI;

DROP TABLE LabManager;

DROP TABLE Contains_LabMember;

DROP TABLE Lab;

commit;