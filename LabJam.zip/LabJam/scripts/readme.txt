To start application, in sqlplus, run

start drop_table.sql;
start create_table.sql;
start load_labjam.sql;
start projectname_funding.sql;
start projectname_materialprice.sql;